# smartbank-frontend (static)
A minimal static frontend that can be deployed as a **Render Static Site**.

- No build step required.
- Calls the backend at `/api/health` by default (same origin if proxied).
- If your backend is on another domain, set a global variable in a small script tag before the module:
  ```html
  <script>window.SMARTBANK_API = 'https://your-backend.onrender.com';</script>
  ```
