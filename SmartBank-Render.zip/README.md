# SmartBank (Render-ready)
This repository contains a minimal **frontend** and **backend** plus a `render.yaml` so Render can auto-provision both services from one repo.

## Structure
- `smartbank-backend/` – Node/Express API
- `smartbank-frontend/` – static site (no build)
- `render.yaml` – Render configuration

## Deploy (quick)
1. Upload these folders and files to a **new GitHub repo**.
2. On Render, create **New +** ➝ **Blueprint** and select the repo (since we have `render.yaml`).
3. Render will create:
   - A **Web Service** for the backend.
   - A **Static Site** for the frontend.
4. Once live, open the frontend URL and click **Ping API**. If they're on separate domains, set `window.SMARTBANK_API` in `index.html` to your backend URL.

## Local Dev (backend)
```bash
cd smartbank-backend
npm install
npm start
```

## Customize
Replace the placeholder UI and endpoints with your actual SmartBank app.
