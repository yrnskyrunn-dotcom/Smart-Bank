# smartbank-backend (Node/Express)
Simple API server for Render.

## Endpoints
- `GET /api/health` – health check
- `GET /api/loans` – sample data

## Run locally
```bash
npm install
npm start
```
