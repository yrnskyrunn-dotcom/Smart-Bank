const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 10000;
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';

app.use(cors({ origin: CORS_ORIGIN }));
app.use(express.json());

// Health endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'smartbank-backend',
    time: new Date().toISOString()
  });
});

// Example loans endpoint (placeholder)
app.get('/api/loans', (req, res) => {
  res.json([
    { id: 1, amount: 10000, currency: 'PLN', termMonths: 12, rate: 0.07 },
    { id: 2, amount: 480000, currency: 'PLN', termMonths: 240, rate: 0.07 }
  ]);
});

app.listen(PORT, () => {
  console.log(`SmartBank backend running on port ${PORT}`);
});
